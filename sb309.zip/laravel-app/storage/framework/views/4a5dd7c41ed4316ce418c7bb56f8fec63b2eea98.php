<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <title>インス○もどき→ユーザー情報</title>
    <link rel="icon" href="<?php echo e(asset('fuca_tehepero_icon_32x32.ico')); ?>" sizes="32x32">
</head>
<body>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        ユーザーID： <?php echo e($user->id); ?><br>
        メールアドレス： <?php echo e($user->email); ?><br>
        <span style="font-size: 16px; font-weight: bold;"><?php echo e($user->name); ?>さん</span><br>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>                                                                                                                     <?php /**PATH /var/www/resources/views/user.blade.php ENDPATH**/ ?>