<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <title>インス○もどきホーム</title>
    <link rel="icon" href="<?php echo e(asset('fuca_tehepero_icon_32x32.ico')); ?>" sizes="32x32">
</head>
<body>


<?php if(isset($images)): ?>  
<ul>
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="images/<?php echo e($image->filename); ?>" target="_brank">
            <img src="images/<?php echo e($image->filename); ?>" width="120px" height="100px" />
        </a>   
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<!-- エラーメッセージ。なければ表示しない -->
<?php if($errors->any()): ?>
<ul>
    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<!-- フォーム -->
<form action="<?php echo e(url('upload')); ?>" method="POST" enctype="multipart/form-data">

    <input type="hidden" name="user_id" value="<?php echo e($request->user_id); ?>">
    <label for="photo">画像ファイル:</label>
    <input type="file" class="form-control" name="file">
    <br>
    <input type="text" class="form-control" name="message">
    <hr>
    <?php echo e(csrf_field()); ?>

    <button class="btn btn-succes"> Upload </button>
</form>

</body>
</html><?php /**PATH /var/www/resources/views/home.blade.php ENDPATH**/ ?>