<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <title>インス○もどき→ユーザー情報</title>
    <link rel="icon" href="<?php echo e(asset('fuca_tehepero_icon_32x32.ico')); ?>" sizes="32x32">
</head>
<body>
    <?php echo e($username); ?> さん、ようこそいらっしゃいまし。

</body>
</html>                                                                                                                     <?php /**PATH /var/www/resources/views/user.blade.php ENDPATH**/ ?>